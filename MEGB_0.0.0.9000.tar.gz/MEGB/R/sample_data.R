
#' Simulated sample data
#'
#' The data set includes domains, covariates, epsilon and target variable y
#'
#' @format ## `sample_data`
#' A data frame with 1000 observations and 8 variables:
#' \describe{
#'    \item{y}{numeric; the target variable.}
#'    \item{x1}{numeric; first covariate}
#'    \item{x2}{numeric; second covariate}
#'    \item{x3}{numeric; third covariate}
#'    \item{x4}{numeric; fourth covariate}
#'    \item{x5}{numeric; fifth covariate}
#'    \item{epsilon}{numeric; error}
#'    \item{domain}{numeric; domain}
#' }
#' @docType data
  "sample_data"
