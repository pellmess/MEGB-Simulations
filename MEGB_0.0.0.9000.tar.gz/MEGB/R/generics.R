
# generics

#' Coef Method for megb Class
#' @param megb_object object of class MEGB containing the boosting model
#' @param ... additional arguments
#' @return List containing random effects coefficients and feature importance
#' @export
coef.megb <- function(megb_object, ...) {
  UseMethod("coef", megb_object)
}


#' Default Coef Method for MEGB Class
#' @param megb_object object of class MEGB containing the boosting model
#' @param ... additional arguments
#' @return List of random effects coefficients and feature importance
#' @export
coef.MEGB <- function(megb_object, ...) {
  list(
    feature_importance = megb_object$gbmodel$importance_matrix,
    random_effects = unclass(coef(megb_object$gbmodel$effect_model))[[1]]
  )
}

#' Save objects of class MEGB
#' @param megb_object object of class MEGB containing the boosting model
#' @param file file to save object to
#' @param ... additional arguments
#' @return NULL invisibly
#' @export
save_megb <- function(megb_object, file, ...) {
  saveRDS(megb_object, file = file)
}

#' Load objects of class MEGB
#' @param file file to load object from
#' @param ... additional arguments
#' @return an R object
#' @export
load_megb <- function(file, ...) {
readRDS(file)
}

